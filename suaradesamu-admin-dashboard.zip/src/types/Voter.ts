export type Voter = {
  id: number;
  nfcSerialNumber: string;
  NIK: string;
  name: string;
};
