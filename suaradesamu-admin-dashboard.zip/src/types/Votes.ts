export type Votes = {
  totalPemilih: number;
  totalSuaraMasuk: number;
  totalSuaraMasukDalamPersen: number;
  isVotingRun: boolean;
};
